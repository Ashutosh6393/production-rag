"""Document vector-indexing orchestration."""
